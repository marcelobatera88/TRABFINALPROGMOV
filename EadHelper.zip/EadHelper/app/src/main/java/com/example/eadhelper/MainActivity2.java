package com.example.eadhelper;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity2 extends AppCompatActivity {
    private DBHelper helper=new DBHelper(this);
    private EditText edtNome;
    private EditText edtEmail;
    private EditText edtUsuario;
    private EditText edtSenha;
    private EditText edtConfSenha;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        edtNome=findViewById(R.id.edtNome);
        edtEmail=findViewById(R.id.edtEmail);
        edtUsuario=findViewById(R.id.edtUsuario);
        edtSenha=findViewById(R.id.edtSenha);
        edtConfSenha=findViewById(R.id.edtConfSenha);
    }

    public void cancelar(View view) {
        finish();
    }

    public void cadastrar(View view) {
        String nome=edtNome.getText().toString();
        String email=edtEmail.getText().toString();
        String usr=edtUsuario.getText().toString();
        String senha=edtSenha.getText().toString();
        String confSenha=edtConfSenha.getText().toString();
        if(!senha.equals(confSenha)){
            Toast toast=Toast.makeText(MainActivity2.this, "Senha difere da confirmação de senha!",Toast.LENGTH_SHORT);
            toast.show();
            edtSenha.setText("");
            edtConfSenha.setText("");
        }else{
            Usuario c = new Usuario();
            c.setNome(nome);
            c.setEmail(email);
            c.setUsuario(usr);
            c.setSenha(senha);
            helper.inserirContato(c);
            Toast toast=Toast.makeText(MainActivity2.this,
                    "Cadastro realizado com sucesso!",Toast.LENGTH_SHORT);
            toast.show();
            limpar();
        }
    }
    private void limpar() {
        edtNome.setText("");
        edtEmail.setText("");
        edtUsuario.setText("");
        edtSenha.setText("");
        edtConfSenha.setText("");
    }
}