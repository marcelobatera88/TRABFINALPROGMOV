package com.example.eadhelper;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class CadastroAulaE extends AppCompatActivity {
    private EditText edtNomeCurso;
    private EditText edtHora;
    private EditText edtLink;

    AulaDB AulaDB;
    Aula DBaula;
    private int aulaDBID;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro_aula_e);

        AulaDB = AulaDB.getDatabase(getApplicationContext());

        Button btnSal = findViewById(R.id.btnSal);
        Button btnCan = findViewById(R.id.btnCan);
        edtNomeCurso = findViewById(R.id.edtNomeCurso);
        edtHora = findViewById(R.id.edtHora);
        edtLink = findViewById(R.id.edtLink);

        aulaDBID = getIntent().getIntExtra("AULA_SELECIONADA_ID", -1);

        btnCan.setOnClickListener(this::onClick);

        btnSal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nomeAula = edtNomeCurso.getText().toString();
                String horarioAula = edtHora.getText().toString();
                String linkEad = edtLink.getText().toString();

                if (nomeAula.equals("")){
                    alert("Você DEVE colocar um nome!");
                    return;
                }
                if (horarioAula.equals("")){
                    alert("Você DEVE colocar um horário!");
                    return;
                }

                Aula aula = new Aula();
                aula.setNomeAula(nomeAula);
                aula.setHorarioAula(Integer.parseInt(horarioAula));
                aula.setLinkEad(linkEad);

                if (DBaula == null){
                    AulaDB.aulaAlarme().insertAll(aula);
                    alert("Aviso: Aula salva!");

                }
                else {
                    AulaDB.aulaAlarme().update(aula);
                    alert("Aviso: Foram Atualizados os Dados!");
                    alert("Aula atualizada com sucesso!");

                }
                finish();
            }
        });
    }
    @Override
    protected void onResume() {
        super.onResume();
        if (aulaDBID >= 0){
            preencherAula();
        }
    }
    private void preencherAula(){
        DBaula = AulaDB.aulaAlarme().get(aulaDBID);
        edtNomeCurso.setText(DBaula.getNomeAula());
        edtHora.setText(DBaula.getHorarioAula());
        edtLink.setText(DBaula.getLinkEad());
    }
    private void alert(String s){
        Toast.makeText(this,s,Toast.LENGTH_SHORT).show();
    }

    private void onClick(View v) {
        finish();
    }
}