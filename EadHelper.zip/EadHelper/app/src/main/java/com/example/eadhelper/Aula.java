package com.example.eadhelper;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity
public class Aula {
    @PrimaryKey(autoGenerate = true)
    Integer aulaID;

    @ColumnInfo(name = "nomeAula")
    String nomeAula;

    @ColumnInfo(name = "horarioAula")
    int horarioAula;

    @ColumnInfo(name = "linkEad")
    String linkEad;

    public Integer getAulaID() {
        return aulaID;
    }

    public void setAulaID(Integer aulaID) {
        this.aulaID = aulaID;
    }

    public String getNomeAula() {
        return nomeAula;
    }

    public void setNomeAula(String nomeAula) {
        this.nomeAula = nomeAula;
    }

    public int getHorarioAula() {
        return horarioAula;
    }

    public void setHorarioAula(int horarioAula) {
        this.horarioAula = horarioAula;
    }

    public String getLinkEad() {
        return linkEad;
    }

    public void setLinkEad(String linkEad) {
        this.linkEad = linkEad;
    }

    @Override
    public String toString() {
        return
                "ID:" + aulaID +
                        ", nome da aula = " + nomeAula +
                        ", horario = " + horarioAula
                ;
    }
}
