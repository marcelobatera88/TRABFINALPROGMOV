package com.example.eadhelper;

import android.content.Intent;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.List;

public class MainActivity3 extends AppCompatActivity {
    AulaDB AulaDB;
    Button btnCadR;
    ListView listAulas;
    Aula aula;
    private int id1, id2;
    List<Aula> aulas;
    Intent intent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
        btnCadR = findViewById(R.id.btnCadR);
        listAulas = findViewById(R.id.listAulas);
        registerForContextMenu(listAulas);
        AulaDB = AulaDB.getDatabase(getApplicationContext());
        btnCadR.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent it = new Intent(MainActivity3.this,CadastroAulaE.class);
                startActivity(it);
            }
        });

    }

    @Override
    protected void onResume() {
        super.onResume();
        intent = new Intent(this,CadastroAulaE.class);
        preencherLista();
    }

    public void preencherLista(){
        aulas = AulaDB.aulaAlarme().getAll();
        ArrayAdapter<Aula> aulaArrayAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, aulas);
        listAulas.setAdapter(aulaArrayAdapter);
        listAulas.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Aula aulaSel = aulas.get(position);
                intent.putExtra("AULA_SELECIONADA_ID", aulaSel.aulaID);
                startActivity(intent);
            }
        });
        listAulas.setOnItemLongClickListener((parent, view, position, id) -> {
            aula = aulaArrayAdapter.getItem(position);
            return false;
        });

    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        MenuItem mDelete = menu.add(Menu.NONE,id1,1,"Deletar Aula");
        MenuItem mSai = menu.add(Menu.NONE,id2,2,"Cancelar");
        mDelete.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                AulaDB.aulaAlarme().delete(aula);
                alert("Aula excluida");
                preencherLista();
                return false;
            }
        });
        super.onCreateContextMenu(menu,v,menuInfo);
    }
    private void alert(String s){
        Toast.makeText(this,s,Toast.LENGTH_SHORT).show();
    }
}