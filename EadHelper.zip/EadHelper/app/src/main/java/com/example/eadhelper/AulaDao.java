package com.example.eadhelper;


import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface AulaDao {
    @Query("SELECT * FROM Aula WHERE aulaID = :id LIMIT 1")
    Aula get(int id);

    @Query("SELECT * FROM Aula")
    List<Aula> getAll();

    @Query("SELECT * FROM Aula WHERE aulaID IN (:aulaId)")
    List<Aula> loadAllByIds(int[] aulaId);

    @Query("SELECT * FROM Aula WHERE nomeAula LIKE :nomeAula LIMIT 1")
    Aula findByName(String nomeAula);

    @Insert
    void insertAll(Aula... aula);

    @Update
    void update(Aula aula);

    @Delete
    void delete(Aula aula);

}
